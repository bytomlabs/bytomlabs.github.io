---
title: ASIC矿机
---

# ASIC矿机

<a name="8fb09e7e"></a>
## ASIC矿机型号

Bitmain B3<br />Bitmain B7

<a name="2cc4e65f"></a>
## **配置矿池矿工**

a、点击”Miner Configuration“ 进入矿池和矿工配置页面。<br />b、URL里面填写的是矿池地址。<br />c、User是矿工名，对应矿池里的子账号,编号是区分矿机的编号。<br />d、Password不用更改(默认即可)。<br />e、设置完后，点击“Save&Apply"进行保存。

<a name="9706537f"></a>
## 查看运行状态
**<br />![](https://cdn.nlark.com/yuque/0/2019/png/241708/1555046814325-94ed501a-51d0-4d73-90af-3b869949da23.png#align=left&display=inline&height=259&originHeight=663&originWidth=1910&size=0&status=done&width=746)

详细教程：[B7矿机使用说明](https://support.bitmain.com/hc/zh-cn/articles/360020739874-B7%E7%9F%BF%E6%9C%BA%E4%BD%BF%E7%94%A8%E8%AF%B4%E6%98%8E)
