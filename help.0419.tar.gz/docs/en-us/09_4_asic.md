---
title: ASIC Mining
---

# ASIC Mining

<a name="97a3528f"></a>
## ASIC Hardware

Bitmain B3<br />Bitmain B7

<a name="b8d4e9eb"></a>
## Miner Configuration

* Click the “Miner Configuration” tab and then “General Settings” to setup the mining pools. Key in the mining pool URL and miner name (under Worker).
* There is no need to change the Password.
* Then click “Save&Apply” to connect to the mining pools.

<a name="db729547"></a>
## Miner Status

The configuration is now complete. It will take about 5 to 30 minutes to get the mining started.<br />**<br />![](https://cdn.nlark.com/yuque/0/2019/png/241708/1555046814325-94ed501a-51d0-4d73-90af-3b869949da23.png#align=left&display=inline&height=259&originHeight=663&originWidth=1910&size=0&status=done&width=746)

Document:[How to set up a new B3](https://support.bitmain.com/hc/en-us/articles/360008436094-How-to-set-up-a-new-B3)
