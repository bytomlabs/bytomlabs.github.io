---
title: Bytom Kit
---

# Bytom Kit

![](https://cdn.nlark.com/yuque/0/2019/jpeg/241708/1555061604856-6d4eb430-287e-470a-9fcb-5f13575d4e81.jpeg#align=left&display=inline&height=504&originHeight=824&originWidth=1220&size=0&status=done&width=746)

Bytom Kit is a development aid that integrates functions such as Verify, Sign, Decode Raw Transaction, and Testnet Faucet.

URL:[https://blockmeta.com/tools/key](https://blockmeta.com/tools/key)
